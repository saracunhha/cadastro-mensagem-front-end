
import './App.css';
import { AppRouter } from './routes';
import { AuthProvider } from './Auth/AuthContext';




export const App = () =>
{
  return (
    <AuthProvider>
      <AppRouter />
      </AuthProvider>
    
  );
}